# Kod symulatora ryzyka
