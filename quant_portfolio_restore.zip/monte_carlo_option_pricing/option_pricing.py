# Kod do wyceny opcji Monte Carlo
