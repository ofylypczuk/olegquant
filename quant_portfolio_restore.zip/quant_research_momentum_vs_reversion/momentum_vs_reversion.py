# Kod porównania momentum vs reversion
