# Kod rolling Sharpe/vol
