# Kod do analizy benchmarku
