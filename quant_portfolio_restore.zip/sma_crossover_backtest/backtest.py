# Kod strategii SMA crossover
